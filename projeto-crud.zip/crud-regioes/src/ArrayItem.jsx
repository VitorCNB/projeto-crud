export function ArrayItem({ id, deleteArray, uf, region }) {
    return (
      <li>

        <label>
          {uf}
        </label>
        
        <label>
          {region}
        </label>
        
        <button onClick={() => deleteArray(id)}>
          Delete
        </button>
        
      </li>
    )
  }