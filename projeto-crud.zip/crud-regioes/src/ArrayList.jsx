import { ArrayItem } from "./ArrayItem"

export function ArrayList({ array, deleteArray }) {
  return (
    <ul className="list">
      {array.length === 0 && "Sem regiões cadastradas"}
      {array.map(array => {
        return (
          <arrayItem
            {...array}
            key={array.id}
            deleteArray={deleteArray}
          />
        )
      })}
    </ul>
  )
}