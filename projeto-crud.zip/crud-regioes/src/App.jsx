import { Form } from "./Form"
import { useState } from "react"
import { ArrayList } from "./ArrayList"
import "./Style.css"


function App() {
  const [array, setArray] = useState([])

  function addArray(uf, region){
    setArray(currentArray => {
      return [
        ...currentArray,
        { id: crypto.randomUUID(), uf, region, situation : true },
      ]
    })
  }
  function deleteArray(id) {
    setArray(currentArray => {
      return currentArray.filter(array => array.id !== id)
    })
  }
  
  return (
    <>
      <div>
        <h1 className="header">Cadastro de regiões</h1>
      </div>
      <Form onSubmit={addArray}/>
      <ArrayList array={array} deleteArray={deleteArray}/>
    
    </>   
  )
}

export default App